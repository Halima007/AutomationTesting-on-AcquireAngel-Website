package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Dashboard_Seller_Settings {

public static void main(String[] args) throws InterruptedException {
		
		// WebDriverManager Setup for the Chrome browser
		WebDriverManager.chromedriver().setup();

		
		// WebDriver object create for the Chrome browser
		WebDriver driver=new ChromeDriver();

		// URL Visit
		driver.get("https://www.acquireangel.com/signin");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();



		//InputBox
		//1. Id:- Edit username inputbox data using id locator
		Thread.sleep(4000);
		driver.findElement(By.id("Email")).sendKeys("qoq57460@zwoho.com");
		
		Thread.sleep(2000);
		//2. Name:- Edit password inputbox data using name locator
		driver.findElement(By.name("Password")).sendKeys("123456");
		driver.findElement(By.xpath("//input[@id='IsRemember']")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button[class='btn btn-primary btn-block']")).click();
		
		driver.get("https://www.acquireangel.com/settings");
		
		driver.findElement(By.linkText("Change Password")).click();
		driver.findElement(By.name("CurrentPassword")).sendKeys("123456");
		driver.findElement(By.name("Password")).sendKeys("456789");
		driver.findElement(By.name("ConfirmPassword")).sendKeys("456789");
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input[value='Change ']")).click();
		
		driver.navigate().back();
		
		Thread.sleep(2000);
		driver.findElement(By.linkText("Sign Out")).click();
		
		driver.get("https://www.acquireangel.com/signin");
		
		Thread.sleep(2000);
		
		driver.findElement(By.id("Email")).sendKeys("qoq57460@zwoho.com");
		driver.findElement(By.name("Password")).sendKeys("456789");
		driver.findElement(By.xpath("//input[@id='IsRemember']")).click();
		driver.findElement(By.cssSelector("button[class='btn btn-primary btn-block']")).click();
		
		driver.get("https://www.acquireangel.com/settings");
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input[value='Archive account ']")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.linkText("Sign Out")).click();

	}

}
