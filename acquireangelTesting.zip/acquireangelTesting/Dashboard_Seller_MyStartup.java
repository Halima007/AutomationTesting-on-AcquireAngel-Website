package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Dashboard_Seller_MyStartup {

public static void main(String[] args) throws InterruptedException {
		
		// WebDriverManager Setup for the Chrome browser
		WebDriverManager.chromedriver().setup();

		
		// WebDriver object create for the Chrome browser
		WebDriver driver=new ChromeDriver();

		// URL Visit
		driver.get("https://www.acquireangel.com/signin");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();



		//InputBox
		//1. Id:- Edit username inputbox data using id locator
		Thread.sleep(4000);
		driver.findElement(By.id("Email")).sendKeys("qoq57460@zwoho.com");
		
		Thread.sleep(2000);
		//2. Name:- Edit password inputbox data using name locator
		driver.findElement(By.name("Password")).sendKeys("123456");
		
		driver.findElement(By.xpath("//input[@id='IsRemember']")).click();
		
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button[class='btn btn-primary btn-block']")).click();
		
		
		driver.findElement(By.name("StartupName")).sendKeys("Mr.A");
		driver.findElement(By.name("Email")).sendKeys("qoq57460@zwoho.com");
		driver.findElement(By.name("Website")).sendKeys("www.myprofile.com");
		
		Thread.sleep(4000);
		
		driver.findElement(By.cssSelector("input[value='Save']")).click();
		
		//Public Information
		Thread.sleep(4000);
		
		
		//About company
		driver.findElement(By.id("Startup_AboutCompany")).sendKeys("This is a SoftwareCompany");
		
		//Annual Recurring Revenue
		driver.findElement(By.id("Startup_AnnualRecurringRevenue")).sendKeys("5,00,000");
		
		//Number Of Customers
		Select dropdown =new Select(driver.findElement(By.id("Startup_NumberOfCustomers")));
		Thread.sleep(2000);
		
		Thread.sleep(3000);
		dropdown.selectByValue("10-100");
		
		//Date Founded
		Select dropdown2 =new Select(driver.findElement(By.id("Startup_FoundedYear")));
		Thread.sleep(2000);
		
		Thread.sleep(3000);
		dropdown2.selectByValue("1991");
		
		Select dropdown3 =new Select(driver.findElement(By.id("Startup_FoundedMonth")));
		Thread.sleep(2000);
		
		Thread.sleep(3000);
		dropdown3.selectByValue("April");
		
		//Asking price
		driver.findElement(By.id("Startup_AskingPrice")).sendKeys("10,000");
		
		//Open to offers
		driver.findElement(By.cssSelector(".slider.round")).click();
		
		//Startup team size
		driver.findElement(By.id("Startup_StartupTeamSize")).sendKeys("10");
		
		//update button
		driver.findElement(By.cssSelector("form[id='publicInfoForm'] button[type='submit']")).click();
		
		//Company Features
		
		//Growth Opportunity
		driver.findElement(By.name("Features.GrowthOpportunity")).sendKeys("All Is Well");
		
		//Add Highlights
		driver.findElement(By.id("GrowthOpportunityHighlights")).click();
		driver.findElement(By.name("Features.GrowthOpportunityHighlights")).sendKeys("Testing");
		
		
		driver.findElement(By.id("KeyAssetsHighlights")).click();
		driver.findElement(By.cssSelector("input[placeholder='KeyAssets Highlights']")).sendKeys("Bug");
		
		//keywords
		driver.findElement(By.id("Features_Keywords")).sendKeys("Software, testing, quality");
		
		//update button
		driver.findElement(By.cssSelector("form[id='companyFeaturesForm'] button[type='submit']")).click();
		
		//Selling Details
		
		//Why are you selling?
		driver.findElement(By.id("Details_Reason")).sendKeys("I made it for selling purpose");
		
		//Financial / funding
		driver.findElement(By.id("Details_Financial")).sendKeys("1,00,000");
		
		//update button
		driver.findElement(By.cssSelector("form[id='companySellingDetails'] button[type='submit']")).click();
	}

}
