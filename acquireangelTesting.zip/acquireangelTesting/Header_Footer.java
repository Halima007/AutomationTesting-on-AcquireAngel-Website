package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Header_Footer {

	public static void main(String[] args) throws InterruptedException {
		// WebDriverManager Setup for the Chrome browser
				WebDriverManager.chromedriver().setup();

				
				// WebDriver object create for the Chrome browser
				WebDriver driver=new ChromeDriver();

		// URL Visit
		driver.get("https://www.acquireangel.com/");
		
		driver.manage().window().maximize();
		
		//Header
		
		//icon
				Thread.sleep(5000);
				
				driver.findElement(By.linkText("acquireangel")).click();
				
				
				//nav
				Thread.sleep(4000);
				
				driver.findElement(By.linkText("For Sellers")).click();
				
				Thread.sleep(5000);
				driver.navigate().back();
				
				Thread.sleep(4000);
				
				driver.findElement(By.linkText("For Buyers")).click();
				
				Thread.sleep(5000);
				driver.navigate().back();
				
				Thread.sleep(4000);
				
				driver.findElement(By.linkText("About")).click();
				
				Thread.sleep(5000);
				driver.navigate().back();
				
				
				Thread.sleep(4000);
				
				driver.findElement(By.linkText("SignIn")).click();
				
				Thread.sleep(5000);
				driver.navigate().back();
				
				
				Thread.sleep(4000);
				
				driver.findElement(By.linkText("Join Now")).click();
				
				Thread.sleep(5000);
				driver.navigate().back();
				
				//Footer
				
				Thread.sleep(2000);
				driver.findElement(By.cssSelector("input[placeholder='Enter email address']")).sendKeys("far@gmail.com");
				
				Thread.sleep(2000);
				driver.findElement(By.cssSelector("input[value='Subscribe']")).click();
				
				Thread.sleep(4000);
				
				driver.findElement(By.cssSelector(".icon-twitter")).click();
				
				Thread.sleep(4000);
				
				driver.findElement(By.cssSelector(".icon-facebook")).click();
				
				Thread.sleep(4000);
				
				driver.findElement(By.cssSelector(".icon-instagram")).click();

	}

}
