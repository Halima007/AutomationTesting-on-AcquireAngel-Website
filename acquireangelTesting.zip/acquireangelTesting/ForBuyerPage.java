package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ForBuyerPage {

	public static void main(String[] args) throws InterruptedException {
		// WebDriverManager Setup for the Chrome browser
				WebDriverManager.chromedriver().setup();

				
				// WebDriver object create for the Chrome browser
				WebDriver driver=new ChromeDriver();

		// URL Visit
		driver.get("https://www.acquireangel.com/buyers");
		driver.manage().deleteAllCookies();
		
		driver.manage().window().maximize();
		
		Thread.sleep(4000);
		
		driver.findElement(By.cssSelector(".btn.btn-primary.px-4.py-3.mt-3")).click();

	}

}
