package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HomePage_webelements {

	public static void main(String[] args) throws InterruptedException {
		// WebDriverManager Setup for the Chrome browser
				WebDriverManager.chromedriver().setup();

				
				// WebDriver object create for the Chrome browser
				WebDriver driver=new ChromeDriver();

		// URL Visit
		driver.get("https://www.acquireangel.com/");
		
		driver.manage().window().maximize();

		
		//prev-after
		Thread.sleep(4000);
		driver.findElement(By.className("owl-next")).click();
		
		Thread.sleep(4000);
		driver.findElement(By.className("owl-prev")).click();
		
		Thread.sleep(4000);
		
		driver.findElement(By.className("owl-next")).click();
		
		//vdo play
		
		Thread.sleep(4000);
		
		driver.findElement(By.className("ion-ios-play")).click();
		
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//button[contains(text(),'�')]")).click();
		
		//join now
		
		Thread.sleep(4000);
		
		driver.findElement(By.linkText("Join Now")).click();
		
		Thread.sleep(5000);
		driver.navigate().back();
		
		
		
		
		
		
		
		
	}

}

