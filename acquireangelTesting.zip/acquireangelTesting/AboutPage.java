package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AboutPage {

	public static void main(String[] args) throws InterruptedException {
		// WebDriverManager Setup for the Chrome browser
				WebDriverManager.chromedriver().setup();

				
				// WebDriver object create for the Chrome browser
				WebDriver driver=new ChromeDriver();
				
				// URL Visit
				driver.get("https://www.acquireangel.com");
				
				Thread.sleep(4000);
				driver.get("https://www.acquireangel.com/about");
				
				Thread.sleep(4000);
				
				driver.findElement(By.cssSelector("button[class='owl-dot']")).click();
				
				Thread.sleep(2000);
				
				driver.findElement(By.xpath("//body/section[1]/div[1]/div[2]/div[1]/div[1]/div[3]/button[1]")).click();
				
				
				

	}

}


