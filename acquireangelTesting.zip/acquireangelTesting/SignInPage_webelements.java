package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SignInPage_webelements {
	public static void main(String[] args) throws InterruptedException {
		
		// WebDriverManager Setup for the Chrome browser
		WebDriverManager.chromedriver().setup();

		
		// WebDriver object create for the Chrome browser
		WebDriver driver=new ChromeDriver();

		// URL Visit
		driver.get("https://www.acquireangel.com/signin");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();



		//InputBox
		//1. Id:- Edit username inputbox data using id locator
		Thread.sleep(2000);
		driver.findElement(By.id("Email")).sendKeys("fgd09996@boofx.com");
		
		Thread.sleep(2000);
		//2. Name:- Edit password inputbox data using name locator
		driver.findElement(By.name("Password")).sendKeys("12345");
		
		Thread.sleep(2000);
		//3. Xpath:- RememberMe checkbox testing using Xpath locator
				driver.findElement(By.xpath("//input[@id='IsRemember']")).click();
				
		//button Test
		Thread.sleep(2000);
		//4. :- SignIn button testing using CssSelector locator
		driver.findElement(By.cssSelector("button[class='btn btn-primary btn-block']")).click();
				
		
			
				
			
			}
		
		}
