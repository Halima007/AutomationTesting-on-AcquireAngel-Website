package acquireangelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Dashboard_Marketplace {

public static void main(String[] args) throws InterruptedException {
		
		// WebDriverManager Setup for the Chrome browser
		WebDriverManager.chromedriver().setup();

		
		// WebDriver object create for the Chrome browser
		WebDriver driver=new ChromeDriver();

		// URL Visit
		driver.get("https://www.acquireangel.com/signin");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();



		//InputBox
		//1. Id:- Edit username inputbox data using id locator
		Thread.sleep(4000);
		driver.findElement(By.id("Email")).sendKeys("qoq57460@zwoho.com");
		
		Thread.sleep(2000);
		//2. Name:- Edit password inputbox data using name locator
		driver.findElement(By.name("Password")).sendKeys("123456");
		
		driver.findElement(By.xpath("//input[@id='IsRemember']")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button[class='btn btn-primary btn-block']")).click();
		
		driver.get("https://www.acquireangel.com/marketplace");
		
		//
		driver.findElement(By.id("min_price")).sendKeys("10");
		
		driver.findElement(By.id("max_price")).sendKeys("700");
		
		Select dropdown =new Select(driver.findElement(By.id("customer_number")));
		Thread.sleep(2000);
		dropdown.selectByVisibleText("100-1000");
		
		driver.findElement(By.id("searchbox")).sendKeys("New Tech");
		
		Thread.sleep(5000);
		driver.findElement(By.id("reload")).click();
		
		Thread.sleep(5000);
		driver.findElement(By.cssSelector("div[class='container font-12px'] div:nth-child(2) div:nth-child(1) div:nth-child(1) div:nth-child(1) div:nth-child(3) a:nth-child(1) i:nth-child(1)")).click();
		
		Thread.sleep(5000);
		driver.findElement(By.id("Message")).sendKeys("I want to buy");
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("button[type='submit']")).click();
	}

}
